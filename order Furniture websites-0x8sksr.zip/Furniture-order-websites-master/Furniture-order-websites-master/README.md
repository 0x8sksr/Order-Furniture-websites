> This is final design for website.

# [Link website](file:///C:/Users/Shubham%20Kumar/Desktop/Furniture-order-websites-master/index.html)

---

### Table of Contents
You're sections headers will be used to reference location of destination.

- [Description](#description)
- [How To Use](#how-to-use)
- [Author Info](#author-info)

---

## Description

This is my repository for slicing my design landing page furniture order website.

#### Technologies

- HTML
- CSS
- Javascript
- Bootstrap
- GSAP

[Back To The Top](#read-me-for-furniture-order-websites)

---

## How To Use

#### Installation
Just download the file via zip file or fork my repository.


## Author Info

- Instragram - [@0x8sksr](https://instagram.com/0x8sksr)
- Website - [Padlabs.id](https://0x8sksr.github.io/)

[Back To The Top](#read-me-for-furniture-order-websites)
